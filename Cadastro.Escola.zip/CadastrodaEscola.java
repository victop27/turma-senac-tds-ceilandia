/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.com.senac.cadastrodaescola;

/**
 *
 * @author ana62977736
 */
public class CadastrodaEscola {

    public static void main(String[] args) {

        Pessoa aluno = new Aluno("Ana Beatrice");
        Pessoa professor = new Professor("Bruna");

        aluno.apresentar();
        professor.apresentar();
    }
}