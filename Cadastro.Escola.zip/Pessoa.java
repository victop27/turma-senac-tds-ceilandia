/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package  br.com.senac.cadastrodaescola;

/**
 *
 * @author ana62977736
 */
public class Pessoa {
   
    protected String nome;

    public Pessoa(String nome) {
        this.nome = nome;
    }

    public void apresentar() {
        System.out.println("Olá, sou uma pessoa.");
    }
}