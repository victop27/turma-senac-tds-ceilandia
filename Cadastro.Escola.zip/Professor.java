/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.com.senac.cadastrodaescola;

/**
 *
 * @author ana62977736
 */
public class Professor extends Pessoa{
    
    public Professor(String nome) {
        super(nome);
    }

    @Override
    public void apresentar() {
        System.out.println("Olá, sou o professor. Me chamo " + nome);
    }
}